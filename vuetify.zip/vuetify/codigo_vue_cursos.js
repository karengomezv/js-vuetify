const url = "http://localhost:4000/cursos/";

new Vue({
  el: '#app',
  vuetify: new Vuetify(),
  data: () => ({
    search: '', //para el cuadro de búsqueda de datatables  
    snackbar: false, //para el mensaje del snackbar   
    textSnack: 'texto snackbar', //texto que se ve en el snackbar 
    dialog: false, //para que la ventana de dialogo o modal no aparezca automáticamente      
    //definimos los headers de la datatables  
    headers: [
      {
        text: 'ID',
        align: 'left',
        sortable: false,
        value: 'id',
      },
      { text: 'NOMBRE', value: 'nombre' },
      { text: 'CLAVE', value: 'clave' },
      { text: 'CREDITOS ', value: 'creditos' },
      { text: 'ACCIONES', value: 'accion', sortable: false },
    ],
    cursos: [], 
    editedIndex: -1,
    editado: {
      id: '',
      nombre: '',
      clave: '',
      creditos: '',
    },
    defaultItem: {
        id: '',
        nombre: '',
        clave: '',
        creditos: '',
    },
     

  }),

  computed: {
    //Dependiendo si es Alta o Edición cambia el título del modal  
    formTitle() {
      //operadores condicionales "condición ? expr1 : expr2"
      // si <condicion> es true, devuelve <expr1>, de lo contrario devuelve <expr2>    
      return this.editedIndex === -1 ? 'Nuevo Registro' : 'Editar Registro'
    },
  },

  watch: {
    dialog(val) {
      val || this.cancelar()
    },
  },

  mounted() {
    this.listarMoviles()
  },

  methods: {
    //PROCEDIMIENTOS para el CRUD  
    //Procedimiento Listar moviles  
    listarMoviles: function () {
      // axios.post(url).then(response =>{
      //    this.estudiantes = response.data;       
      // });
      fetch("http://localhost:4000/cursos")
        .then(response => {
          return response.json();
        })
        .then(data => {
          this.cursos = data
          console.log(data);
        });


    },
    //Procedimiento Alta de moviles.
    altaMovil: function () {
      axios.post(url, {
        opcion: 1, nombre: this.nombre, clave: this.clave, creditos: this.creditos
      }).then(response => {
        this.listarMoviles();
      });
      this.nombre = "",
        this.clave = "",
        this.creditos = 0
    },
    //Procedimiento EDITAR.
    editarMovil: function (id, nombre, matricula, semestreIngreso, creditosCursados) {
      axios.put(url+id, {id: id, nombre: this.nombre, clave: this.clave, creditos: this.creditos
      }).then(response => {
        this.listarMoviles();
      });
    },
    //Procedimiento BORRAR.
    borrarMovil: function (id) {
      axios.delete(url+id).then(response => {
        this.listarMoviles();
      });
    },
    editar(item) {
      this.editedIndex = this.cursos.indexOf(item)
      this.editado = Object.assign({}, item)
      this.dialog = true
    },
    borrar(item) {
      const index = this.cursos.indexOf(item)

      console.log(this.cursos[index].id) //capturo el id de la fila seleccionada 
      const r = confirm("¿Está seguro de borrar el registro?");
      if (r == true) {
        this.borrarMovil(this.cursos[index].id)
        this.snackbar = true
        this.textSnack = 'Se eliminó el registro.'
      } else {
        this.snackbar = true
        this.textSnack = 'Operación cancelada.'
      }
    },
    cancelar() {
      this.dialog = false
      this.editado = Object.assign({}, this.defaultItem)
      this.editedIndex = -1
    },
    guardar() {
      if (this.editedIndex > -1) {
        //Guarda en caso de Edición
        this.id = this.editado.id
        this.nombre = this.editado.nombre
        this.clave = this.editado.clave
        this.creditos = this.editado.creditos
        this.snackbar = true
        this.textSnack = '¡Actualización Exitosa!'
        this.editarMovil(this.id, this.nombre, this.clave, this.creditos)
      } else {
        //Guarda el registro en caso de Alta  
        if (this.editado.nombre == "" || this.editado.clave == "" || this.editado.creditos == 0) {
          this.snackbar = true
          this.textSnack = 'Datos incompletos.'
        } else {
            this.nombre = this.editado.nombre
            this.clave = this.editado.clave
            this.creditos = this.editado.creditos
            this.snackbar = true
          this.snackbar = true
          this.textSnack = '¡Alta exitosa!'
          this.altaMovil()
        }
      }
      this.cancelar()
    },
  },
});