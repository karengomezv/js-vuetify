const url = "http://localhost:4000/estudiantes/";

new Vue({
  el: '#app',
  vuetify: new Vuetify(),
  data: () => ({
    search: '', //para el cuadro de búsqueda de datatables  
    snackbar: false, //para el mensaje del snackbar   
    textSnack: 'texto snackbar', //texto que se ve en el snackbar 
    dialog: false, //para que la ventana de dialogo o modal no aparezca automáticamente      
    //definimos los headers de la datatables  
    headers: [
      {
        text: 'ID',
        align: 'left',
        sortable: false,
        value: 'id',
      },
      { text: 'NOMBRE', value: 'nombre' },
      { text: 'MATRICULA', value: 'matricula' },
      { text: 'SEMESTRE DE INGRESO', value: 'semestreIngreso' },
      { text: 'CREDITOS CURSADOS', value: 'creditosCursados' },
      { text: 'ACCIONES', value: 'accion', sortable: false },
    ],
    estudiantes: [], //definimos el array m
    editedIndex: -1,
    editado: {
      id: '',
      nombre: '',
      matricula: '',
      semestreIngreso: '',
      creditosCursados: '',
    },
    defaultItem: {
      id: '',
      nombre: '',
      matricula: '',
      semestreIngreso: '',
      creditosCursados: '',
    },
     

  }),

  computed: {
    //Dependiendo si es Alta o Edición cambia el título del modal  
    formTitle() {
      //operadores condicionales "condición ? expr1 : expr2"
      // si <condicion> es true, devuelve <expr1>, de lo contrario devuelve <expr2>    
      return this.editedIndex === -1 ? 'Nuevo Registro' : 'Editar Registro'
    },
  },

  watch: {
    dialog(val) {
      val || this.cancelar()
    },
  },

  mounted() {
    this.listarMoviles()
  },

  methods: {
    //PROCEDIMIENTOS para el CRUD  
    //Procedimiento Listar moviles  
    listarMoviles: function () {
      // axios.post(url).then(response =>{
      //    this.estudiantes = response.data;       
      // });
      fetch("http://localhost:4000/estudiantes")
        .then(response => {
          return response.json();
        })
        .then(data => {
          this.estudiantes = data
          console.log(data);
        });


    },
    //Procedimiento Alta de moviles.
    altaMovil: function () {
      axios.post(url, {
        opcion: 1, nombre: this.nombre, matricula: this.matricula, semestreIngreso: this.semestreIngreso,
        creditosCursados: this.creditosCursados
      }).then(response => {
        this.listarMoviles();
      });
      this.nombre = "",
        this.matricula = "",
        this.semestreIngreso = "",
        this.creditosCursados = 0
    },
    //Procedimiento EDITAR.
    editarMovil: function (id, nombre, matricula, semestreIngreso, creditosCursados) {
      axios.put(url+id, {id: id, nombre: nombre, matricula: matricula, semestreIngreso: semestreIngreso,
        creditosCursados: creditosCursados
      }).then(response => {
        this.listarMoviles();
      });
    },
    //Procedimiento BORRAR.
    borrarMovil: function (id) {
      axios.delete(url+id).then(response => {
        this.listarMoviles();
      });
    },
    editar(item) {
      this.editedIndex = this.estudiantes.indexOf(item)
      this.editado = Object.assign({}, item)
      this.dialog = true
    },
    borrar(item) {
      const index = this.estudiantes.indexOf(item)

      console.log(this.estudiantes[index].id) //capturo el id de la fila seleccionada 
      const r = confirm("¿Está seguro de borrar el registro?");
      if (r == true) {
        this.borrarMovil(this.estudiantes[index].id)
        this.snackbar = true
        this.textSnack = 'Se eliminó el registro.'
      } else {
        this.snackbar = true
        this.textSnack = 'Operación cancelada.'
      }
    },
    cancelar() {
      this.dialog = false
      this.editado = Object.assign({}, this.defaultItem)
      this.editedIndex = -1
    },
    guardar() {
      if (this.editedIndex > -1) {
        //Guarda en caso de Edición
        this.id = this.editado.id
        this.nombre = this.editado.nombre
        this.matricula = this.editado.matricula
        this.semestreIngreso = this.editado.semestreIngreso
        this.creditosCursados = this.editado.creditosCursados
        this.snackbar = true
        this.textSnack = '¡Actualización Exitosa!'
        this.editarMovil(this.id, this.nombre, this.matricula, this.semestreIngreso, this.creditosCursados)
      } else {
        //Guarda el registro en caso de Alta  
        if (this.editado.nombre == "" || this.editado.matricula == "" || this.editado.semestreIngreso == "" || this.editado.creditosCursados == 0) {
          this.snackbar = true
          this.textSnack = 'Datos incompletos.'
        } else {
          this.nombre = this.editado.nombre
          this.matricula = this.editado.matricula
          this.semestreIngreso = this.editado.semestreIngreso
          this.creditosCursados = this.editado.creditosCursados
          this.snackbar = true
          this.textSnack = '¡Alta exitosa!'
          this.altaMovil()
        }
      }
      this.cancelar()
    },
  },
});