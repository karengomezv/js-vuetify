const db = require('../models/database/db');

exports.findAll = async function () { 
   let student = await db.Estudiante.findAll();
   let arregloCursos = [], impresion = [];

   for (let a = 0; a < student.length; a++) {
      impresion[a] = {
         "id": student[a].id,
         "nombre": student[a].nombre,
         "matricula": student[a].matricula,
         "semestreIngreso": student[a].semestreIngreso,
         "creditosCursados": student[a].creditosCursados
      };
   }
   return impresion;
}


exports.findById = async function (value) {
   let inscritos, impresion;
   let student = await db.Estudiante.findAll({
      where: {
         id: value
      }
   });
 
   impresion = {
      "id": student[0].id,
      "nombre": student[0].nombre,
      "matricula": student[0].matricula,
      "semestreIngreso": student[0].semestreIngreso,
      "creditosCursados": student[0].creditosCursados,
   };
   return impresion;
}

mostrarCursos = async function (value) {
   let student = await db.Estudiante.findAll({ 
      where: {
         id: value
      }
   });
   return student[0].getCursos(); 
}

exports.findByMatricula = async function (mat) {
   let inscritos, impresion;
   let student = await db.Estudiante.findAll({
      where: {
         matricula: mat
      }
   });

   impresion = {
      "id": student[0].id,
      "nombre": student[0].nombre,
      "matricula": student[0].matricula,
      "semestreIngreso": student[0].semestreIngreso,
      "creditosCursados": student[0].creditosCursados,
   //   "cursos": inscritos
   };
   return impresion;
}

exports.add = async function (name, mat, semestreI, creditos) { 
   let student = await db.Estudiante.create({
      nombre: name,
      matricula: mat,
      semestreIngreso: semestreI,
      creditosCursados: creditos
   });
   return student;
}

exports.save = async function (identificador, name, semestreI, creditos) {
   let student = await db.Estudiante.update({
      nombre: name,
      semestreIngreso: semestreI,
      creditosCursados: creditos
   }, {
      where: {
         id: identificador
      }
   });

   return student;
}

exports.delete = async function (value) {
   let student = await db.Estudiante.destroy({
      where: {
         id: value
      }
   });
   return student;
}