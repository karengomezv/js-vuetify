const Sequelize = require('sequelize');
const sequelize = new Sequelize(
    'escuela',
    'root',
    'kgv123.',
    {
        host: 'localhost',
        dialect: 'mysql'
    });

const Estudiante =
    sequelize.define('curso', {
        //atributos
        claveCurso: {
            type: Sequelize.INTEGER,
            allowNull: false
        },
        nombreCurso: {
            type: Sequelize.STRING,
            allowNull: false,
            unique: true
        },
        creditos: {
            type: Sequelize.INTEGER,
            allowNull: true,
            defaultValue: 0
        }
    });
Estudiante.sync({ force: true });