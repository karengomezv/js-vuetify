const db = require('../models/database/db');
db.Curso.findAll().
    then((res) => {
        res.forEach(rec => {
            console.log(
                rec.claveCurso,
                rec.nombreCurso,
                rec.creditos);
        })
        db.sequelize.close();
    });